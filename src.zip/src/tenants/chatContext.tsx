import { createContext } from 'react';

export const chatContext = createContext({} as any);
export const formContext = createContext({} as any);
export const videCallContext = createContext({} as any);