export type { ExternalProps,
            AsyncProps, 
            GetData,
            Message,
            Attachment,
            TimeMessageProps }  from "./InterfaceChat";

// export type { ICaseDataResponse } from '../services/my-case/ICaseDataResponse'
